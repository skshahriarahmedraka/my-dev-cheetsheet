
## 1(a)
  2016 1(a)

## 1(b)
  CREATE TABLE Student (
    std-id 
    name 
    faculty-id 
  )
  CREATE TABLE Department (
    dept-id 
    dept-name 
  ) 
  CREATE  TABLE District (
    dist-code 
    District-name
  )
